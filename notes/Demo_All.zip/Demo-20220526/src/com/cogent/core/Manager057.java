package com.cogent.core;

class MySingletonClass{
	//Step 1
	private MySingletonClass() {
		super();
	}
	
	private static MySingletonClass obj;
	
	public static MySingletonClass getObject(){
		if(obj==null)
			obj= new MySingletonClass();
		
		return obj;
	}
	
}

public class Manager057 {
	public static void main(String[] args) {
		//MySingletonClass m1= new MySingletonClass();
		//MySingletonClass m2= new MySingletonClass();
		//System.out.println(m1==m2);
		
		MySingletonClass m1= MySingletonClass.getObject();
		MySingletonClass m2= MySingletonClass.getObject();
		System.out.println(m1==m2);
		
		
	}
}
