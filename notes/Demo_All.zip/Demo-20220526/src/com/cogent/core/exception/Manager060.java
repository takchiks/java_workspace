package com.cogent.core.exception;

public class Manager060 {
	public static void main(String[] args) {
		System.out.println("main starts");
		try {
			String s1= args[0];
			String s2= args[1];
			System.out.println(s1+" : "+s2);
			System.out.println(s1+s2);//10 20= 1020
			// Arithmetic Operation
			int i1= Integer.parseInt(s1); 
			int i2= Integer.parseInt(s2);
			System.out.println("Sum: "+(i1+i2));
			
		}
		catch(ArrayIndexOutOfBoundsException aioebe) {
			System.out.println("Please provide CLA");
			aioebe.printStackTrace();
		}
		catch (NumberFormatException nfe) {
			System.out.println("Please enter only numeric values in CLA");
			nfe.printStackTrace();
		}
		catch (Exception e) {
			System.out.println();
			e.printStackTrace();
		}
		
		
		
		System.out.println("main ends");
	}
}
