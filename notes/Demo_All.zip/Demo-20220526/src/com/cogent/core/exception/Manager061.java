package com.cogent.core.exception;

public class Manager061 {
	public static void main(String[] args) {
		System.out.println("main starts");
		try {
			System.out.println("Open the file");
			System.out.println("Reading file1.....");
			System.out.println("Reading file2.....");
			System.out.println("Reading file3.....");
			System.out.println("Reading file4.....");
			int i = 10 / 0;// Arithmetic Exception
			System.out.println("Reading file5.....");
			System.out.println("Reading file6.....");
			System.out.println("Reading file7.....");
			System.out.println("Reading file8.....");
			
		} catch (NumberFormatException ae) {
			ae.printStackTrace();
		}
		finally {
			System.out.println("Mandatory task: close the file");	
		}
		
		System.out.println("main ends");
	}
}
