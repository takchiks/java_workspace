package com.cogent.core.exception;

import java.io.FileOutputStream;

class A063{
	void test1()throws ClassNotFoundException {
		test3();
		System.out.println("test1");
	}
	static void test2()throws ClassNotFoundException {
		new A063().test1();
		System.out.println("test2");
	}
	void test3() throws ClassNotFoundException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("test3");
	}
}

public class Manager063 {
	public static void main(String[] args) throws ClassNotFoundException{
		new Manager063().test4();
	}
	void test4()throws ClassNotFoundException {
		A063.test2();
		System.out.println("test4");
		
		
		
	}
}
