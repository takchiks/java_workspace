package com.cogent.core.exception;

class BankAccount{
	String acHolder;
	int balance;
	public BankAccount(String acHolder, int balance) {
		super();
		this.acHolder = acHolder;
		this.balance = balance;
	}
	 void withdraw(int amt) {
		 System.out.println("Current Balance: "+ balance);
		 if(balance>=amt) {
			 balance=balance-amt;
			 System.out.println("Please collect the cash. Remaining Balance: "+ balance);
		 }else {
			 throw new ArithmeticException("Dont try to act smart");
		 }
	 }
}
public class Manager064 {
	public static void main(String[] args) {
		BankAccount acc1= new BankAccount("Mardochee", 1000);
		acc1.withdraw(1500);
	}
}
