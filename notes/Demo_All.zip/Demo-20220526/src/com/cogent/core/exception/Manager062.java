package com.cogent.core.exception;

import java.io.IOException;

public class Manager062 {
	public static void main(String[] args) {
		int i=10/0;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
