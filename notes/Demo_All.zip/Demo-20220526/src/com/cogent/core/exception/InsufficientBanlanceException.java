package com.cogent.core.exception;

public class InsufficientBanlanceException extends ArithmeticException {

}
