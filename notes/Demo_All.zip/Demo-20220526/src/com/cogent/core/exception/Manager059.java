package com.cogent.core.exception;

public class Manager059 {
	public static void main(String[] args) {
		System.out.println("Main starts");
		try {
			String s1= args[0];
			String s2= args[1];
			System.out.println(s1+" : "+s2);
		}catch(ArrayIndexOutOfBoundsException aioebe) {
			aioebe.printStackTrace();
		}
		System.out.println("main ends");
	}
}
