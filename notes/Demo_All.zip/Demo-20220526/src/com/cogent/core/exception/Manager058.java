package com.cogent.core.exception;
// java Manager058 10 20 30
public class Manager058 {
	public static void main(String[] args) {
		System.out.println("main started");
		String s1=args[0];
		System.out.println(s1);
		System.out.println("main ends");
	}
}
