package com.hp;
class A022 extends Object{
	int i=10;
	
	@Override
	public String toString() {
		return "Value of I: "+ i;
	}
}
public class Manager022 extends Object {
	public static void main(String[] args) {
		A022 a1= new A022();
		
		A022 a2= new A022();
		a2.i=100;
		
		System.out.println(a1);
		System.out.println(a2);
		
		
		//System.out.println(a1.toString());
		//System.out.println(a1.hello());
	}
}


/*
 * Methods in Object class
 * 1. toString()
 * 2. equals()
 * 3. hashcode()
 * 4. clone()
 * 5. wait()
 * 6. notify()
 * 7. notifyAll()
 */
