package com.hp;
import com.dell.A;
public class Manager018 {
	void test() {
		A a1= new A();
		//System.out.println(a1.a);
		//System.out.println(a1.b);
		//System.out.println(a1.c);
		System.out.println(a1.d);
	}
	public static void main(String[] args) {
		new Manager018().test();
	}
}
