package com.hp;
import com.dell.A;
public class Manager019 extends A {
	void test() {
		//System.out.println(a);
		//System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
	public static void main(String[] args) {
		new Manager019().test();
	}
	/*
	 * java.lang- No need to import
	 * java.sql
	 * java.util
	 * java.io
	 * java.nio.....
	 */
}
