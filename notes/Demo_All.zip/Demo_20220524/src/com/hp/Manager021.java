package com.hp;
class Car021{
	private String brand="Hyundai";
	private String model="Elantra";
	private int milege=20;
	
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getMilege() {
		return milege;
	}
	public void setMilege(int milege) {
		this.milege = milege;
	}
}
public class Manager021 {
	public static void main(String[] args) {
		Car021 car1= new Car021();
		System.out.println(car1);//com.hp.Car021@5e91993f
		Car021 car2=new Car021();
		car2.setBrand("Toyota");
		car2.setModel("Etios");
		car2.setMilege(25);
		System.out.println(car2);//com.hp.Car021@156643d4
		
		//com.hp.Car021       @         5e91993f
		//classname @ Hexadecimal representation of memory address
	}
}
