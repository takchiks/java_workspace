package com.cogent.core;

class Person011{
	private String name;
	private int age;
	
	public void setName(String name){
		this.name=name;
	}
	public String getName(){
		return name;
	}
	
	public void setAge(int age){
		if(age>0) {
			this.age= age;	
		}else {
			this.age=1;
		}
	}
	public int getAge(){
		return age;
	}
	
}

public class Manager011 {
	public static void main(String[] args) {
		Person011 person= new Person011();
		person.setName("Jayant");
		
		//person.name="Jayant";
		//person.age=-100;
		
		System.out.println(person.getName());
		
	}
}
