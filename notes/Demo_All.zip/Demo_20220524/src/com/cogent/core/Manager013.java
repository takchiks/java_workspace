package com.cogent.core;


class Father{
	void drive() {
		System.out.println("I drive Car");
	}
}
class Son extends Father{
	// static methods can't be inherited
}

public class Manager013 {
	public static void main(String[] args) {
		Father father= new Father();
		//father.drink();//The method drink() is undefined for the type Father
		father.drive();
		
		
		Son son= new Son();
		son.drive();
		
	}
}
