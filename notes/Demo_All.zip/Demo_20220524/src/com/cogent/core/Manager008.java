package com.cogent.core;

public class Manager008 {
	int i=10;
	void test() {
		int i=100;
		System.out.println(i);
		// In case of conflict-Local variables get more preference over global variable
	}
	
	public static void main(String[] args) {
		new Manager008().test();
	}
}
