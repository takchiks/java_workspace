package com.cogent.core;
class A015{
	//METHOD OVERLOADING- POLYMORPHISM- COMPILE TIME
	void test() {
		System.out.println("0P-test");
	}
	void test(int i) {
		System.out.println("1P-test");
	}
	void test(int i, char c) {
		System.out.println("2P-test-v2");
	}
	void test(int i, boolean b) {
		System.out.println("2P-test-v2");
	}
	void test(boolean b, int i) {
		System.out.println("2P-test-v3");
	}
}
public class Manager015 {

}
