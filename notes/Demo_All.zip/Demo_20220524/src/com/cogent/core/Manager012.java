package com.cogent.core;
//BEAN, POJO-Plain old java object

/*
 * BEAN
 * 1. All attributes should be declared as private
 * 2. Provide setters and Getters for all attributes
 * 3. Provide one public Constructor
 */

class Book {
	private String title;
	private int pages;
	private String author;
	private double price;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
}

public class Manager012 {

}
