package com.cogent.core;

class Father016{
	void drive() {
		System.out.println("Drive Car");
	}
}

class Son016 extends Father016{
	@Override// Annotation
	void drive() {
		System.out.println("Drive Bike");
	}
	
	
	void eat() {
		System.out.println("Eat Meat");
	}
	void drink() {
		System.out.println("Drink Water");
	}
	
}

public class Manager016 {

}
