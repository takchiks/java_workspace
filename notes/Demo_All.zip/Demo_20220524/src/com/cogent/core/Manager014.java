package com.cogent.core;

class A014{
	// Method Signature
	void test() {}
	void test1() {	}// Name
	void test1(int i) {	}//List of Arguments
	void test1(int i, double j) {}//List of Arguments
	void test1(double i, int j) {}//Order of Argument
	//void test1(double j, int i) {}
	//int test1(double i, int j) {return 1;}
}


public class Manager014 {

}
