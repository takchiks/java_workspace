package com.cogent.core;

public class Manager007 {
	int i;// Global Variable-declared outside method
	void test() {
		int j;// Local Variable- declared inside method
		System.out.println(i);
		//System.out.println(j);//The local variable j may not have been initialized
	}
	void testMe() {
		System.out.println(i);
		//System.out.println(j);//j cannot be resolved to a variable
	}
	
	public static void main(String[] args) {
		new Manager007().test();
	}
	
	// Local variable should be initialized explicitly before using it
}
