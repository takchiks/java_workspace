package com.cogent.core;

public class Manager006 {
	
	int i=10;
	void test() {
		System.out.println("I am from test");
	}
	
	public static void main(String[] args) {
		Manager006 m1= new Manager006();
		System.out.println(m1.i);
		m1.test();
	}
}
