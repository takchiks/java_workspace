package com.cogent.core;

public class Manager009 {
	int i=10;
	void test() {
		int i=100;
		System.out.println(i);// Local i-100
		
		Manager009 m1= new Manager009();
		System.out.println(m1.i);// Global i-10
		
		System.out.println(this.i);// Global i-10
	}
	
	public static void main(String[] args) {
		new Manager009().test();
	}
}
