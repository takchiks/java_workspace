package com.cogent.core;


class Person010{
	String name="Jayant";
	static int age=100;
	
	void greet() {
		System.out.println("Hey "+name);
	}
}


public class Manager010 {
	int i=10;
	
	public static void main(String[] args) {
		Manager010 m= new Manager010();
		System.out.println(m.i);
		//System.out.println(this.i);//Cannot use this in a static context
		
		
		System.out.println(Person010.age);
		
		Person010 person= new Person010();
		person.greet();
		
	}
	
}
