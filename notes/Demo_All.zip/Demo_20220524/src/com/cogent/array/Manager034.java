package com.cogent.array;

class A034{
	int i=10;
}
class B034 extends A034{
	int i=20;
}
public class Manager034 {
	public static void main(String[] args) {
		
	}
	void test() {
		B034 b1= new B034();
		System.out.println(b1.i);
	}
}







