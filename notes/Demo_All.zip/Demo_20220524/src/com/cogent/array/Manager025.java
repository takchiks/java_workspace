package com.cogent.array;

public class Manager025 {
	public static void main(String[] args) {
		int [] arr1= new int[5];
		System.out.println(arr1);//[I@626b2d4a
		
		double [] arr2= new double[4];
		System.out.println(arr2);//[D@5e265ba4
	}
}
