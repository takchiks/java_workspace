package com.cogent.array;

public class Manager026 {
	public static void main(String[] args) {
		int [] arr1= new int[5];
		System.out.println(arr1.length);
		
		int [] arr2= new int[0];//Empty Array
		// Inside Empty Array- We can't store a single value
		System.out.println(arr2.length);
		
		
		int [] arr3= {};// Empty Array
		System.out.println(arr3.length);
		
		int [] arr4= null;// Null Array
		System.out.println(arr4.length);// java.lang.NullPointerException:
		
	}
}
