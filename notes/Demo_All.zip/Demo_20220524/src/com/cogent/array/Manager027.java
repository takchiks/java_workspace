package com.cogent.array;

public class Manager027 {
	public static void main(String[] args) {
		new Manager027().test(new int[] {2,4,6,1,2,5});// Anonymous Array
	}
	void test(int arr[]) {
		System.out.println(arr.length);
	}
}
