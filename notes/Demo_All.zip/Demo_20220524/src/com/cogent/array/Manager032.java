package com.cogent.array;

import java.util.Scanner;



public class Manager032 {
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		System.out.println("Please enter number 1");
		int nm1=scanner.nextInt();
		System.out.println("Please enter number 2");
		int nm2=scanner.nextInt();
		System.out.println("Sum of 2 numbers are: "+(nm1+nm2));
	}
}
