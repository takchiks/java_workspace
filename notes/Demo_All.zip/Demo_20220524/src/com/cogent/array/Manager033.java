package com.cogent.array;

import java.util.Arrays;
import java.util.Scanner;
class Customer033{
	private int custId;
	private String custName;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	@Override
	public String toString() {
		return "Customer033 [custId=" + custId + ", custName=" + custName + "]";
	}

}
public class Manager033 {
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number of Customers to be added");
		int num=sc.nextInt();
		Customer033 [] customers= new Customer033[num];
		for(int i=0; i<num; i++) {
			Customer033 customer= new Customer033();
			System.out.println("Please enter customer Id");
			customer.setCustId(sc.nextInt());
			System.out.println("Please enter customer Name");
			customer.setCustName(sc.next());
			customers[i]=customer;
		}
		
		System.out.println(Arrays.toString(customers));
	}
}







