package com.cogent.array;

import java.util.Arrays;

class Customer031{
	private int custId;
	private String custName;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	@Override
	public String toString() {
		return "Customer031 [custId=" + custId + ", custName=" + custName + "]";
	}
	
}

public class Manager031 {
	public static void main(String[] args) {
		int arr[]= new int[5];
		Customer031 customers[]= new Customer031[5];
		customers[0]= new Customer031();
		customers[1]= new Customer031();
		customers[2]= new Customer031();
		customers[3]= new Customer031();
		System.out.println(Arrays.toString(customers));
		
	}
}
