package com.cogent.array;

public class Manager024 {
	public static void main(String[] args) {
		int arr[]= {10,400,30,50,1,333};
		System.out.println(arr[5]);
	}
}
