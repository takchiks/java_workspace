package com.cogent.array;

public class Manager023 {
/*
 * 1. It contains Homogeneous data: Collection of similar data types
 * 2. Fixed size
 * 3. To maintain the insertion order, Index is used
 * 4. Contiguos Memory Allocation
 * 5. Data Manipulation- Painful
 * 6. No direct way to print the data
 * 
 */
	
	public static void main(String[] args) {
		int arr[]= new int[5];
		int []arr1= new int[5];
		
		arr[0]= 10 ;
		arr[1]= 100;
		arr[2]= 500;
		arr[3]= 50 ;
		arr[4]= 30;
		//arr[5]=1000;//java.lang.ArrayIndexOutOfBoundsException
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
		System.out.println("Element @ index 3 is: "+ arr[3]);
	}
}
