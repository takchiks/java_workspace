package com.cogent.array;

import java.util.Arrays;

public class Manager030 {

	
	public static void main(String[] args) {
		int arr[]= new int[5];
		arr[0]= 10 ;
		arr[1]= 100;
		arr[2]= 500;
		arr[3]= 50 ;
		arr[4]= 30;
		
		System.out.println(Arrays.toString(arr));
		//Arrays.sort(arr);
		//System.out.println(Arrays.toString(arr));
		int index=Arrays.binarySearch(arr, 500);
		if(index>=0) {
			System.out.println("Element found at index: "+index);
		}
		else {
			System.out.println("Element not present");
		}
		
	}
}
