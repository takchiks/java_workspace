package com.cogent.array;

public class Manager028 {
	public static void main(String[] args) {
		int [] x= new int[5];
		int [] y= new int[4];
		x=y;
	}
	
}
