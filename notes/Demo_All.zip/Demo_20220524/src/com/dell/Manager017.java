package com.dell;

public class Manager017 {
	void test() {
		A a1= new A();
		//System.out.println(a1.a);//The field A.a is not visible
		System.out.println(a1.b);
		System.out.println(a1.c);
		System.out.println(a1.d);
	}
	public static void main(String[] args) {
		new Manager017().test();
	}
}
