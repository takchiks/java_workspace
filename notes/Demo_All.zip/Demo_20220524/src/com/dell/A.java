package com.dell;

public class A {
	private int a=10;
	int b=20;
	protected int c=30;
	public int d=40;
}
