package com.dell;
import java.util.*;
public class Manager020 {
	public static void main(String[] args) {
		ArrayList list= new ArrayList();
		String s= new String();// from java.lang package
	}
}
