package com.cogent.core;
public class Manager04 {
	int i=10;
	static int j=20;
	public static void main(String[] args) {
		System.out.println(j);
		Manager04 m1= new Manager04();
		System.out.println(m1.i);
	}
	
	// Non static members can be accessed inside static context through Object creation
}
