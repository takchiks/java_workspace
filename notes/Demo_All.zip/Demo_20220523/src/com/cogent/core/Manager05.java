package com.cogent.core;

public class Manager05 {
	public static void main(String[] args) {
		System.out.println("I am from main");
		
		Manager05 m1= new Manager05();
		m1.test();
		
		//new Manager05().test();
	}
	void test() {
		display();
		System.out.println("I am from test");
	}
	void display() {
		hello();
		//new Manager05().hello();// static member:WARNING
		System.out.println("I am from display");
	}
	static void hello() {
		System.out.println("I am from hello");
	}
}
