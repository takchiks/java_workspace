package com.cogent.core;

//byte,short, int, long,float, double, char, boolean
class Person{
	String name;
	int age;
	double weight;
	static String country;
}
public class Manager03 {
	public static void main(String[] args) {
		
		Person p1= new Person();
		p1.name="Jayant";
		p1.age=100;
		p1.weight=200;
		
		Person p2= new Person();
		p2.name="Phil";
		p2.age=80;
		p2.weight=300;
		
		p1=p2;
	}
}
