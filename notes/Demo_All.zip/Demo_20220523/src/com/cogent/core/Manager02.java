package com.cogent.core;

public class Manager02 {
	int i=10;//non-static
	static int j=20;//static
	
	public static void main(String[] args) {
		System.out.println(j);
		//System.out.println(i);//Cannot make a static reference to the non-static field i
	}
	
	
	void test() {
		System.out.println(i);
		System.out.println(j);
	}
	
	
	//non static members(variable/methods) can't be accessed inside static context directly
	// vice versa is not true
}
