package com.cogent.constructor;

class A036{
	A036(){
		// Default constructor
	}
	A036(int i){
		// Paramaterized constructor
	}
	A036(int i, int j){
		// Paramaterized constructor
	}
}
public class Manager036 {
	public static void main(String[] args) {
		A036 a1= new A036();
	}
}
