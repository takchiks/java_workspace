package com.cogent.constructor;

class Person039{
	private int personId;
	private String personName;
	public Person039(int personId, String personName) {
		this.personId=personId;
		this.personName= personName;
		System.out.println("PC-Person039");
	}
	public Person039() {
		System.out.println("DC-Person039");
	}
	// Setter Getter
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String toString() {
		return personId+" : "+personName;
	}
}
public class Manager039 {
	public static void main(String[] args) {
		Person039 person1= new Person039();// using DC
		person1.setPersonId(1001);
		person1.setPersonName("Omar");
		
		Person039 person2= new Person039(1002, "Kisa");
		
		System.out.println(person1);
		System.out.println(person2);
	}
}
