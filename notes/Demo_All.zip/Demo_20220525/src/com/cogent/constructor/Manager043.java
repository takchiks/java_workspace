package com.cogent.constructor;
class A043{
	public A043() {}
	public A043(int i) {}
	public A043(char c) {}
	public A043(String s) {}
	public A043(int i, char c) {}
	public A043(boolean b) {}
	public A043(short s, String str) {}
	public A043(int i, int j) {}
	public A043(float f) {}
	public A043(String s, int i) {}
	
	// IIB- Instance Initialization block
	{
		System.out.println("Object Created!");
	}
	
}
public class Manager043 {
	public static void main(String[] args) {
		A043 a1= new A043();
	}
}
// Object Created