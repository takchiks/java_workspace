package com.cogent.constructor;

class A041{

	public A041() {
		super();
		System.out.println("DC-A041");
	}
	
}
public class Manager041 {
	public static void main(String[] args) {
		A041 a1= new A041();
	}
}
