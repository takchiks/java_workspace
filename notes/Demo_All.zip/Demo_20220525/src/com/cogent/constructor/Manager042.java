package com.cogent.constructor;
class A042{
	public A042() {
		super();
		System.out.println("DC-A");
	}
}
class B042 extends A042{
	public B042() {
		super();
		System.out.println("DC-B");
	}
}
class C042 extends B042{
	public C042() {
		super();
		System.out.println("DC-C");
	}
}
public class Manager042 {
	public static void main(String[] args) {
		C042 c= new C042();
	}
}
