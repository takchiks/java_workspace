package com.cogent.constructor;

class A038{
	A038(){
		System.out.println("DC-A038");
	}
}
public class Manager038 {
	public static void main(String[] args) {
		A038 a= new A038();
	}
}
