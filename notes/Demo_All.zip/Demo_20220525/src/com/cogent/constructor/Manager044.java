package com.cogent.constructor;


class A044{
	A044(){
		this(10);
		System.out.println("DC-A044");
	}
	A044(int i){
		System.out.println("PC-A044");
	}
	
	{
		System.out.println("A044-IIB!");
	}
}
class B044 extends  A044{
	B044(){
		System.out.println("DC-B044");
	}
	B044(int i){
		this();
		System.out.println("PC-B044");
	}
	{
		System.out.println("B044-IIB!");
	}
}
public class Manager044 {
	public static void main(String[] args) {
	
		//A044 a1= new A044();
		B044 b1= new B044(10);
	}
}
// Object Created