package com.cogent.constructor;

class A037{
	A037(String str){
		
	}
}
public class Manager037 {
	public static void main(String[] args) {
		
		//A037 a1= new A037();
	}
}
