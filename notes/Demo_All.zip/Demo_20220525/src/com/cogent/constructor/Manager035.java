package com.cogent.constructor;

public class Manager035 {
	public static void main(String[] args) {
		
	}
	void test1() {
		System.out.println("I am from test1");
		test2();// Calling Statement
		//test3();// Calling stmt dosen't have any definition block
	}
	void test2() {
		System.out.println("I am from test2");
	}
}
