package com.cogent.statics;



public class Manager048 {
	public static void main(String[] args) {
		System.out.println("I am from main");
	}
	
	static {
		System.out.println("I am from SIB Manager048");
	}
	
}
