package com.cogent.statics;
class A047{
	private int i=10;

	private A047() {
		super();
	}
	
}
public class Manager047 {
	public static void main(String[] args) {
		//A047 a= new A047();// Private constructor restrict Object Creation
		//System.out.println(a.i);
	}
}
