package com.cogent.statics;

class Passport045 {
	String name;
	String email;
	long mobile;
	String nationality;
	public Passport045(String name, String email, long mobile, String nationality) {
		super();
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.nationality = nationality;
	}
	
}
public class Manager045 {
	public static void main(String[] args) {
		Passport045 passport1= new Passport045("James", "james@gmail.com", 123456, "US");
		Passport045 passport2= new Passport045("Jack", "Jack@gmail.com", 635546, "US");
		Passport045 passport3= new Passport045("John", "John@gmail.com", 565456, "US");
		Passport045 passport4= new Passport045("Jay", "Jay@gmail.com", 765767, "US");
		Passport045 passport5= new Passport045("Jackson", "Jackson@gmail.com", 767887, "US");
	}
}
