package com.cogent.statics;
class Passport046 {
	String name;
	long mobile;
	static String country;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public static String getCountry() {
		return country;
	}
	public static void setCountry(String country) {
		Passport046.country = country;
	}
	public Passport046(String name, long mobile) {
		super();
		this.name = name;
		this.mobile = mobile;
	}
}
public class Manager046 {
	public static void main(String[] args) {
		//Passport046 p1= new Passport046("Vijaya", 12321);
		//Passport046 p2= new Passport046("Ashish", 15521);
		//Passport046 p3= new Passport046("Brent", 15661);
		//p1.country="US";// you should not access static member using reference variable
		//System.out.println(p2.country);// Not advisable
		//System.out.println(p3.country);// Not advisable
		
		Passport046.country="INDIA";
		
	}
}
