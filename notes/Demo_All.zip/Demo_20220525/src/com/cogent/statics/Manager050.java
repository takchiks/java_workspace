package com.cogent.statics;
class A050{
	static {
		System.out.println("SIB-A050");
	}
	public A050() {
		System.out.println("DC-A050");
	}
	{
		System.out.println("IIB-A050");
	}
}
class B050 extends A050{
	static {
		System.out.println("SIB-B050");
	}
	public B050() {
		System.out.println("DC-B050");
	}
	{
		System.out.println("IIB-B050");
	}
}
public class Manager050 {
	static {
		System.out.println("SIB-Manager050");
	}
	public static void main(String[] args) {
		B050 b1= new B050();
		A050 a1= new A050();
	}
}
