package com.cogent.statics;

class A049{
	static {
		System.out.println("SIB-A");
	}
	public A049() {
		System.out.println("DC-A");
	}
	{
		System.out.println("IIB-A");
	}
	
}

public class Manager049 {
	static {
		System.out.println("SIB-Manager");
	}
	public static void main(String[] args) {
		System.out.println("main starts");
		A049 a= new A049();
		System.out.println("main ends");
	}
}
