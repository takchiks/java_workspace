package com.cogent.finals;
class A051{
	int i=10;
	final int j=20;
	final static double PI= 3.14;
	//final int k;//final variable need to be initialized explicitly at the place of declaration
}
public class Manager051 {
	public static void main(String[] args) {
		A051 a= new A051();
		a.i=100;
		//a.j=200;
	}
}
