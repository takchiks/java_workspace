package com.cogent.finals;
class A052{
	void test() {
		System.out.println("Test");
	}
	final void display() {
		System.out.println("Display");
	}
}
class B052 extends A052{
	@Override
	void test() {
		System.out.println("I am back");
	}
	
	//void display(){	}//Cannot override the final method from A052
}
public class Manager052 {
	public static void main(String[] args) {
	}
}
