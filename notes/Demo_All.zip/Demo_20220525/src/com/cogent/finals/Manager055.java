package com.cogent.finals;
class A055{
	static {
		i=100;
	}
	final static int i;
}
public class Manager055 {
	public static void main(String[] args) {
		System.out.println(A055.i);
	}
}
