package com.cogent.finals;
/*
 * 1. final variable should be initialized explicitly at the place of declaration
 * 2. If final variable is not initialized at the declaration then you can initialize it inside EVERY constructor
 * 3. if not initialized @declaration and constructor also then you can initialize it inside any one (Max one) IIB
 */

class A054{
	final int i=10;
	final int j;
	final int k;
	final int m;
	A054(){
		j=100;
		k=200;
	}
	A054(String s){
		j=300;
		k=400;
	}
	{
		m=1000;
		System.out.println("IIB1");
	}
	{
		//m=200;//The final field m may already have been assigned
		System.out.println("IIB2");
	}
}
public class Manager054 {

}
