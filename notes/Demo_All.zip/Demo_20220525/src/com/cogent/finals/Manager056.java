package com.cogent.finals;

public class Manager056 {
	public static void main(String[] args){
		try {
			Integer i=127;
			Integer j=127;
			System.out.println(i==j);
			
			Class.forName("");
			System.out.println("");
		}catch (ClassNotFoundException e) {
		}
	}
}
