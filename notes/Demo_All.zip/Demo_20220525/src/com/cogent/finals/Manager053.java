package com.cogent.finals;
final class A053{
}
/*
//The type B053 cannot subclass the final class A053
class B053 extends A053{
	
}
*/
public class Manager053 {
	public static void main(String[] args) {
	}
}
