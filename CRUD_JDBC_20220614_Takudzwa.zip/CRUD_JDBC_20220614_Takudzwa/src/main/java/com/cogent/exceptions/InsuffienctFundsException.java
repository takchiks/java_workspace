package com.cogent.exceptions;

public class InsuffienctFundsException extends RuntimeException {


	public InsuffienctFundsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
