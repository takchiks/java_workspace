package com.cogent.mock;

public class Taku {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Result.gameWinner("wwwbbbbbwwww"));

	}

}
